﻿<#
.SYNOPSIS
    Shows a nag message in a full screen window.
#>
[CmdletBinding()]
param(
    [Parameter(Position=0, Mandatory=$true)]
    [string]$Message,
    [string]$BackColor = "ForestGreen",
    [string]$ForeColor = "White",
    [int]$FontSize = 78,
    [string]$Font = "Segoe UI",
    [double]$Opacity = 0.8
)

if ($Opacity -lt 0.1) {
    $Opacity = 0.1
}
echo $PSCommand.Path
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$form = New-Object System.Windows.Forms.Form
$lbl = New-Object System.Windows.Forms.Label
try {
    $form.BackColor = $BackColor
    $form.Opacity = $Opacity
    $form.ControlBox = $false
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
    $form.Text = $Message
    $form.ShowIcon = $false
    $form.ShowInTaskbar = $false
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
    $form.TopMost = $true
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized

    $lbl.Dock = [System.Windows.Forms.DockStyle]::Fill
    $lbl.Font = New-Object System.Drawing.Font -ArgumentList @($Font, $FontSize, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Point, 0)
    $lbl.ForeColor = $ForeColor
    $lbl.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $lbl.Add_Click({$form.Close()})
    $lbl.Text = $Message
    $lbl.AutoEllipsis = $true
    $lbl.UseCompatibleTextRendering = $false # smoother fonts
    $form.Controls.Add($lbl)

    $form.Add_Shown({$form.Activate()})
    $form.ShowDialog() | Out-Null
}
finally {
    if ($form) {
        $form.Dispose()
    }
    if ($lbl) {
        $lbl.Dispose()
    }
}